import React, { Component } from "react";
import { StyleSheet, View, Text, Image, TouchableOpacity, ScrollView, Alert, Button, TextInput} from "react-native";





// import { Icon } from 'react-native-elements';

// export default class BottomBar extends Component {


//     render() {

    
//         return (
//             <View style={[styles.container, this.props.style]}>
//                 <TouchableOpacity style={styles.button}>
//                     <Icon
//                         name='telescope'
//                         type='material-community'
//                         iconStyle={styles.iconActive}
//                     />
//                     <Text style={styles.btnText}>Explore</Text>
//                 </TouchableOpacity>
//             </View>
//         );


//     }


// }


// const styles = StyleSheet.create({
//     container: {
//         flex: 1,
//         flexDirection: 'row',
//         borderRadius: 1,
//         borderColor: 'grey',
//         borderWidth: 0.5,
//         marginTop: 2.5,
//     },
//     btnText: {
//         backgroundColor: "transparent",
//         color: "#9E9E9E",
//         paddingTop: 4,
//         fontSize: 12
//       },
//     icon: {
//         backgroundColor: "transparent",
//         color: "#616161",
//         fontSize: 24,
//         opacity: 0.8,

//       },
//       activeIcon: {
//         backgroundColor: "transparent",
//         color: "#3f51b5",
//         fontSize: 24,
//         opacity: 0.8
//       },
//     img: {

//     },
//     birdName:{

//     },
// });